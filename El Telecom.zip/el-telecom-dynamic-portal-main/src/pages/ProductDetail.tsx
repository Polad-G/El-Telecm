
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProductById } from '../lib/productData';
import { ChevronLeft, Shield, Package, Star, Truck, Check } from 'lucide-react';
import Navbar from '../components/Navbar';
import WhatsAppButton from '../components/WhatsAppButton';

// Məhsul detalları səhifəsi
// Bu səhifə məhsul haqqında ətraflı məlumatları göstərir
const ProductDetail = () => {
  // URL-dən məhsul ID-sini alırıq
  const { id } = useParams<{ id: string }>();
  
  // Məhsul məlumatlarını əldə edirik
  const product = getProductById(id ? parseInt(id) : 0);
  
  // Əgər məhsul tapılmasa
  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Məhsul tapılmadı</h2>
            <p className="text-gray-600 mb-6">Axtardığınız məhsul mövcud deyil və ya silinib.</p>
            <Link to="/" className="btn-primary">
              Ana səhifəyə qayıt
            </Link>
          </div>
        </div>
        <WhatsAppButton />
      </div>
    );
  }
  
  // Səhifə başlığını məhsul adı ilə yeniləyirik
  useEffect(() => {
    document.title = `${product.name} | El Telecom`;
    
    // Komponentin unmount olunması zamanı başlığı geri qaytarırıq
    return () => {
      document.title = 'El Telecom';
    };
  }, [product.name]);
  
  // 3D effekti üçün məhsulun rotasiyasını idarə edirik
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientY - rect.top) / rect.height - 0.5) * 10;
    const y = ((e.clientX - rect.left) / rect.width - 0.5) * -10;
    
    setRotation({ x, y });
  };
  
  const handleMouseLeave = () => {
    setRotation({ x: 0, y: 0 });
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          {/* Geri qayıtmaq üçün link */}
          <Link 
            to="/" 
            className="inline-flex items-center text-telecom-600 hover:text-telecom-700 mb-6 transition-colors"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Bütün məhsullara qayıt
          </Link>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 p-6">
              {/* Məhsul şəkli - 3D effekti ilə */}
              <div 
                className="lg:col-span-1 flex items-center justify-center p-4"
                onMouseMove={handleMouseMove}
                onMouseLeave={handleMouseLeave}
              >
                <div 
                  className="relative w-full max-w-sm transition-transform duration-200 ease-out"
                  style={{
                    transform: `perspective(1000px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
                    transformStyle: 'preserve-3d'
                  }}
                >
                  <div className="aspect-square rounded-2xl overflow-hidden shadow-xl">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* 3D effekti üçün əks-kölgə */}
                  <div 
                    className="absolute inset-0 rounded-2xl shadow-2xl opacity-20 -z-10"
                    style={{
                      transform: 'translateZ(-40px)',
                      filter: 'blur(20px)'
                    }}
                  ></div>
                </div>
              </div>
              
              {/* Məhsul məlumatları */}
              <div className="lg:col-span-2 flex flex-col">
                <div className="mb-4">
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-green-100 text-green-800">
                      {product.condition}
                    </span>
                    <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-blue-100 text-blue-800">
                      {product.memory}
                    </span>
                    <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-purple-100 text-purple-800">
                      {product.color}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={star} 
                          className="h-5 w-5 text-yellow-400 fill-current" 
                        />
                      ))}
                    </div>
                    <span className="text-gray-500 text-sm">(25 rəy)</span>
                  </div>
                  
                  <p className="text-gray-600 mb-6">{product.description}</p>
                  
                  {/* Qiymət bölməsi */}
                  <div className="mb-8 bg-telecom-50 rounded-xl p-4 flex items-end justify-between">
                    <div>
                      {product.oldPrice && (
                        <span className="block text-gray-500 line-through mb-1">
                          {product.oldPrice} ₼
                        </span>
                      )}
                      <span className="text-3xl font-bold text-telecom-800">
                        {product.price} ₼
                      </span>
                    </div>
                    
                    <span className="text-green-600 font-medium text-sm rounded-full bg-green-100 px-3 py-1">
                      {product.oldPrice ? `${Math.round((1 - product.price / product.oldPrice) * 100)}% endirim` : 'Ən yaxşı qiymət'}
                    </span>
                  </div>
                  
                  {/* Zəmanət və çatdırılma məlumatları */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <div className="flex items-start space-x-3 p-4 rounded-lg border border-gray-200">
                      <Shield className="h-5 w-5 text-telecom-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-gray-900">1 İl Rəsmi Zəmanət</h3>
                        <p className="text-sm text-gray-600">Bütün məhsullarda 1 il rəsmi zəmanət.</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3 p-4 rounded-lg border border-gray-200">
                      <Truck className="h-5 w-5 text-telecom-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-gray-900">Çatdırılma</h3>
                        <p className="text-sm text-gray-600">Bakı daxili pulsuz, regionlara çatdırılma.</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Alış düymələri */}
                  <div className="flex flex-col sm:flex-row gap-4">
                    <a 
                      href="tel:+994555868378" 
                      className="btn-primary flex-1 flex justify-center items-center gap-2"
                    >
                      <Phone className="h-5 w-5" />
                      Zəng et və sifariş ver
                    </a>
                    
                    <a 
                      href={`https://wa.me/+994555868378?text=Salam, ${product.name} haqqında məlumat almaq istəyirəm.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#25D366] hover:bg-[#128C7E] text-white px-6 py-3 rounded-lg font-medium transition-colors duration-300 shadow-md flex-1 flex justify-center items-center gap-2"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="h-5 w-5"
                      >
                        <path
                          d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"
                        />
                      </svg>
                      WhatsApp ilə yaz
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Əlavə məlumatlar */}
            <div className="px-6 pb-6">
              <div className="border-t border-gray-200 pt-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Məhsul xüsusiyyətləri</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-medium text-gray-900 mb-3">Texniki xüsusiyyətlər</h3>
                    <ul className="space-y-2">
                      <SpecItem label="Marka" value={product.name.split(' ')[0]} />
                      <SpecItem label="Model" value={product.name} />
                      <SpecItem label="Yaddaş" value={product.memory} />
                      <SpecItem label="Rəng" value={product.color} />
                      <SpecItem label="Vəziyyət" value={product.condition} />
                      <SpecItem label="Zəmanət" value={product.warranty} />
                    </ul>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-medium text-gray-900 mb-3">Alıcılara qeyd</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">Bütün məhsullar tam yoxlanılıb və 1 il zəmanətlidir.</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">Almazdan əvvəl məhsulu yoxlaya bilərsiniz.</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">Nağd və kartla ödəniş mümkündür.</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">Sifariş üçün əlaqə: +994 55 586 83 78</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <WhatsAppButton />
    </div>
  );
};

// Məhsul xüsusiyyətləri üçün item komponenti
const SpecItem = ({ label, value }: { label: string; value: string }) => {
  return (
    <li className="flex justify-between">
      <span className="text-gray-600">{label}:</span>
      <span className="font-medium text-gray-900">{value}</span>
    </li>
  );
};

// Phone ikonu üçün komponent
const Phone = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
    </svg>
  );
};

export default ProductDetail;
