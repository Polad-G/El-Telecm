
import React, { useEffect } from 'react';
import Navbar from '../components/Navbar';
import ProductList from '../components/ProductList';
import AboutSection from '../components/AboutSection';
import ContactSection from '../components/ContactSection';
import WhatsAppButton from '../components/WhatsAppButton';
import { ChevronDown, Smartphone, Check, Tag } from 'lucide-react';

// Ana səhifə komponenti
// Bu səhifə bütün ana bölmələri özündə cəmləşdirir
const Index = () => {
  // Səhifə başlığını təyin edirik
  useEffect(() => {
    document.title = 'El Telecom | İstifadə olunmuş premium telefonlar';
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero bölməsi */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-32 relative overflow-hidden">
        {/* Arxa fon dekorativ elementləri */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-telecom-100 blur-3xl opacity-60"></div>
          <div className="absolute top-1/2 -left-24 w-80 h-80 rounded-full bg-telecom-200 blur-3xl opacity-40"></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Mətn bölməsi */}
            <div className="text-center lg:text-left space-y-6 animate-fade-in">
              
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-telecom-900 leading-tight">
                Keyfiyyətli telefonlar <br />
                <span className="text-telecom-500">əlçatan qiymətə</span>
              </h1>
              
              <p className="text-xl text-gray-600 max-w-2xl mx-auto lg:mx-0">
                El Telecom-dan istifadə edilmiş premium telefonlar. Tam yoxlanılmış, 
                1 il zəmanətli və sərfəli qiymətlərlə. Ən son Texnologiyaya malik telefon modellərdən birini seçərək müasir 
                dünyanin imkanlarından istifadə edin
              </p>
              
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center lg:justify-start mt-8">
                <a href="#products" className="btn-primary">
                  Məhsullara baxın
                </a>
                <a href="#contact" className="btn-secondary">
                  Bizimlə əlaqə
                </a>
              </div>
              
              {/* Üstünlüklər siyahısı */}
              <div className="pt-8 grid grid-cols-2 gap-4 max-w-md mx-auto lg:mx-0">
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-telecom-500" />
                  <span className="text-gray-700">1 il zəmanət</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-telecom-500" />
                  <span className="text-gray-700">Pulsuz çatdırılma</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-telecom-500" />
                  <span className="text-gray-700">Keyfiyyət yoxlaması</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-telecom-500" />
                  <span className="text-gray-700">Əlverişli qiymətlər</span>
                </div>
              </div>
            </div>
            
            {/* Telefon şəkli */}
            <div className="flex justify-center lg:justify-end">
              <div className="relative">
                {/* 3D telefon şəkli */}
                <div className="relative w-72 h-72 sm:w-96 sm:h-96 animate-pulse-subtle">
                <div className="absolute inset-0 flex items-center justify-center">
  <div className="w-64 h-64 sm:w-96 sm:h-96 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 shadow-lg"></div>
</div>
<div className="relative z-10 w-full h-full flex items-center justify-center">
  <Smartphone className="w-48 h-48 sm:w-64 sm:h-64 text-white filter drop-shadow-2xl transform rotate-6 scale-110 transition duration-300 hover:scale-100 hover:rotate-0" />
</div>

                  
                  {/* Qiymət etiketləri */}
                  <div className="absolute top-6 right-12 transform rotate-12 bg-white rounded-lg shadow-lg p-2 animate-bounce">
                    <div className="flex items-center text-telecom-800">
                      <Tag className="h-4 w-4 mr-1" />
                      <span className="font-bold">Bütün Məhsullara Endirim</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Aşağı sürüşmə işarəsi */}
          <div className="flex justify-center mt-12">
            <a 
              href="#products" 
              className="animate-bounce flex flex-col items-center text-telecom-600 hover:text-telecom-700 transition-colors"
            >
              <span className="text-sm font-medium mb-1">Aşağı sürüşün</span>
              <ChevronDown className="h-6 w-6" />
            </a>
          </div>
        </div>
      </section>
      
      {/* Məhsullar bölməsi */}
      <ProductList />
      
      {/* Haqqımızda bölməsi */}
      <AboutSection />
      
      {/* Əlaqə bölməsi */}
      <ContactSection />
      
      {/* Footer */}
      <footer className="bg-telecom-800 text-white py-12">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="h-10 w-10 rounded-full bg-white flex items-center justify-center">
                  <Phone className="h-5 w-5 text-telecom-800" />
                </div>
                <span className="text-xl font-bold">El Telecom</span>
              </div>
              <p className="text-telecom-200 mb-4">
                Keyfiyyətli istifadə edilmiş telefonların etibarlı ünvanı.
                1 il rəsmi zəmanətlə premium telefonlar əlçatan qiymətə.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-white hover:text-telecom-200 transition-colors">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/>
                  </svg>
                </a>
                <a href="#" className="text-white hover:text-telecom-200 transition-colors">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>
                <a href="#" className="text-white hover:text-telecom-200 transition-colors">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
                  </svg>
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Sürətli keçidlər</h3>
              <ul className="space-y-2">
                <li>
                  <a href="/" className="text-telecom-200 hover:text-white transition-colors">Ana səhifə</a>
                </li>
                <li>
                  <a href="#products" className="text-telecom-200 hover:text-white transition-colors">Məhsullar</a>
                </li>
                <li>
                  <a href="#about" className="text-telecom-200 hover:text-white transition-colors">Haqqımızda</a>
                </li>
                <li>
                  <a href="#contact" className="text-telecom-200 hover:text-white transition-colors">Əlaqə</a>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Əlaqə məlumatları</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <svg className="h-6 w-6 mr-2 text-telecom-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span className="text-telecom-200">+994 55 586 83 78</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 mr-2 text-telecom-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span className="text-telecom-200">info@eltelecom.az</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 mr-2 text-telecom-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="text-telecom-200">Bakı şəhəri, Nərimanov rayonu, Əhməd Rəcəbli küçəsi</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-telecom-700 mt-8 pt-8 text-center text-telecom-300 text-sm">
            <p>&copy; {new Date().getFullYear()} El Telecom. Bütün hüquqlar qorunur.</p>
          </div>
        </div>
      </footer>
      
      <WhatsAppButton />
    </div>
  );
};

// Phone ikonu üçün komponent
const Phone = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
    </svg>
  );
};

export default Index;
