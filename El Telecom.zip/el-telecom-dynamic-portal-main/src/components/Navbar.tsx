
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';

// Navbar komponenti
// Bu komponent saytın yuxarı hissəsində yerləşən naviqasiya panelini yaradır
const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Səhifə scroll olunduqda navbar-ın görünüşünü dəyişmək üçün
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass py-2 shadow-md' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="relative h-10 w-10 overflow-hidden rounded-full bg-telecom-500 flex items-center justify-center">
              <Phone className="h-5 w-5 text-white" />
              <div className="absolute inset-0 bg-gradient-to-tr from-telecom-600 to-telecom-400 opacity-60"></div>
            </div>
            <span className="text-xl font-bold text-telecom-800">El Telecom</span>
          </Link>

          {/* Tam ekran menyu */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLink href="/" label="Ana Səhifə" />
            <NavLink href="/#products" label="Məhsullar" />
            <NavLink href="/#about" label="Haqqımızda" />
            <NavLink href="/#contact" label="Əlaqə" />
            <a 
              href="tel:+994555868378" 
              className="btn-primary flex items-center space-x-2 animate-pulse-subtle"
            >
              <Phone className="h-4 w-4" />
              <span>Zəng edin</span>
            </a>
          </div>

          {/* Mobil menyu triggeri */}
          <button 
            className="md:hidden text-telecom-800"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobil menyu */}
      {isOpen && (
        <div className="md:hidden glass animate-fade-in">
          <div className="flex flex-col space-y-4 py-6 px-4">
            <MobileNavLink href="/" label="Ana Səhifə" onClick={() => setIsOpen(false)} />
            <MobileNavLink href="/#products" label="Məhsullar" onClick={() => setIsOpen(false)} />
            <MobileNavLink href="/#about" label="Haqqımızda" onClick={() => setIsOpen(false)} />
            <MobileNavLink href="/#contact" label="Əlaqə" onClick={() => setIsOpen(false)} />
            <a 
              href="tel:+994555868378" 
              className="btn-primary text-center"
              onClick={() => setIsOpen(false)}
            >
              Zəng edin
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

// Tam ekran naviqasiya linki
const NavLink = ({ href, label }: { href: string; label: string }) => (
  <a 
    href={href} 
    className="font-medium text-telecom-800 hover:text-telecom-600 transition-colors relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-full after:origin-left after:scale-x-0 after:bg-telecom-500 after:transition-transform hover:after:scale-x-100"
  >
    {label}
  </a>
);

// Mobil naviqasiya linki
const MobileNavLink = ({ 
  href, 
  label, 
  onClick 
}: { 
  href: string; 
  label: string;
  onClick: () => void;
}) => (
  <a 
    href={href} 
    className="py-2 px-4 font-medium text-telecom-800 hover:bg-telecom-50 rounded-lg transition-colors"
    onClick={onClick}
  >
    {label}
  </a>
);

export default Navbar;
