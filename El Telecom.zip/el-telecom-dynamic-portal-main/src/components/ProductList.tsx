
import React, { useState } from 'react';
import ProductCard from './ProductCard';
import { products } from '../lib/productData';
import { ChevronLeft, ChevronRight } from 'lucide-react';

// Məhsullar siyahısı komponenti
// Bu komponent bütün məhsulları göstərir və səhifələmə (pagination) təmin edir
const ProductList = () => {
  // Səhifə ölçüsü (hər səhifədə neçə məhsul göstəriləcək)
  const pageSize = 4;
  
  // Cari səhifə
  const [currentPage, setCurrentPage] = useState(1);
  
  // Ümumi səhifə sayını hesablayırıq
  const totalPages = Math.ceil(products.length / pageSize);
  
  // Cari səhifədə göstəriləcək məhsulları seçirik
  const currentProducts = products.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
  
  // Əvvəlki səhifəyə keçmək üçün funksiya
  const goToPrevPage = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  };
  
  // Növbəti səhifəyə keçmək üçün funksiya
  const goToNextPage = () => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
  };
  
  // Konkret səhifəyə keçmək üçün funksiya
  const goToPage = (page: number) => {
    setCurrentPage(page);
  };
  
  return (
    <section id="products" className="section-container">
      <h2 className="section-title relative inline-block mx-auto">
        <span className="relative z-10">Məhsullarımız</span>
        <div className="absolute bottom-0 left-0 h-3 w-full bg-telecom-200 -z-10 transform -rotate-1"></div>
      </h2>
      
      {/* Məhsullar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {currentProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      
      {/* Səhifələmə */}
      <div className="flex justify-center items-center space-x-4 mt-10">
        <button
          onClick={goToPrevPage}
          disabled={currentPage === 1}
          className={`p-2 rounded-lg transition-colors ${
            currentPage === 1
              ? 'text-gray-400 cursor-not-allowed'
              : 'text-telecom-600 hover:bg-telecom-50'
          }`}
          aria-label="Əvvəlki səhifə"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        
        <div className="flex space-x-2">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => goToPage(page)}
              className={`h-8 w-8 flex items-center justify-center rounded-lg transition-colors ${
                currentPage === page
                  ? 'bg-telecom-500 text-white'
                  : 'text-gray-700 hover:bg-telecom-100'
              }`}
              aria-label={`${page} səhifəyə keç`}
              aria-current={currentPage === page ? 'page' : undefined}
            >
              {page}
            </button>
          ))}
        </div>
        
        <button
          onClick={goToNextPage}
          disabled={currentPage === totalPages}
          className={`p-2 rounded-lg transition-colors ${
            currentPage === totalPages
              ? 'text-gray-400 cursor-not-allowed'
              : 'text-telecom-600 hover:bg-telecom-50'
          }`}
          aria-label="Növbəti səhifə"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </section>
  );
};

export default ProductList;
