
import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

// Əlaqə bölməsi komponenti
// Bu komponent əlaqə məlumatlarını və əlaqə formasını təqdim edir
const ContactSection = () => {
  return (
    <section id="contact" className="section-container">
      <h2 className="section-title relative inline-block mx-auto">
        <span className="relative z-10">Bizimlə Əlaqə</span>
        <div className="absolute bottom-0 left-0 h-3 w-full bg-telecom-200 -z-10 transform -rotate-1"></div>
      </h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Sol tərəf - Əlaqə məlumatları */}
        <div className="glass rounded-xl p-8 animate-scale-in">
          <h3 className="text-xl font-bold text-telecom-800 mb-6">Əlaqə Məlumatları</h3>
          
          <div className="space-y-4">
            <ContactItem 
              icon={<Phone className="h-5 w-5 text-telecom-500" />}
              title="Telefon"
              detail="+994 55 586 83 78"
              href="tel:+994555868378"
            />
            
            <ContactItem 
              icon={<Mail className="h-5 w-5 text-telecom-500" />}
              title="Email"
              detail="info@eltelecom.az"
              href="mailto:info@eltelecom.az"
            />
            
            <ContactItem 
              icon={<MapPin className="h-5 w-5 text-telecom-500" />}
              title="Ünvan"
              detail="Bakı şəhəri, Nərimanov rayonu, Əhməd Rəcəbli küçəsi"
              href="https://maps.google.com"
            />
            
            <ContactItem 
              icon={<Clock className="h-5 w-5 text-telecom-500" />}
              title="İş saatları"
              detail="Həftəiçi: 09:00 - 19:00, Şənbə: 10:00 - 17:00"
            />
          </div>
          
          <div className="mt-8 p-4 bg-telecom-50 rounded-lg border border-telecom-100">
            <h4 className="font-medium text-telecom-800 mb-2">Qeyd:</h4>
            <p className="text-sm text-gray-600">
              Mağazamıza gəlmədən əvvəl zəng edərək məhsulun mövcudluğunu dəqiqləşdirməyiniz xahiş olunur.
            </p>
          </div>
        </div>
        
        {/* Sağ tərəf - Əlaqə forması */}
        <div className="bg-white rounded-xl shadow-lg p-8 animate-scale-in">
          <h3 className="text-xl font-bold text-telecom-800 mb-6">Bizə mesaj göndərin</h3>
          
          <form className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Ad və Soyad
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-telecom-500 focus:border-transparent"
                  placeholder="Adınızı daxil edin"
                />
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Telefon
                </label>
                <input
                  type="tel"
                  id="phone"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-telecom-500 focus:border-transparent"
                  placeholder="+994 XX XXX XX XX"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-telecom-500 focus:border-transparent"
                placeholder="sizin@email.com"
              />
            </div>
            
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Mesajınız
              </label>
              <textarea
                id="message"
                rows={4}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-telecom-500 focus:border-transparent"
                placeholder="Mesajınızı daxil edin..."
              ></textarea>
            </div>
            
            <button
              type="submit"
              className="w-full btn-primary py-4"
            >
              Göndər
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

// Əlaqə elementləri komponenti
const ContactItem = ({ 
  icon, 
  title, 
  detail, 
  href 
}: { 
  icon: React.ReactNode; 
  title: string; 
  detail: string; 
  href?: string;
}) => {
  const content = (
    <>
      <div className="flex-shrink-0">{icon}</div>
      <div>
        <h4 className="text-sm font-medium text-gray-700">{title}</h4>
        <p className="text-gray-600">{detail}</p>
      </div>
    </>
  );
  
  return (
    <div className="flex items-start space-x-3">
      {href ? (
        <a 
          href={href} 
          className="flex items-start space-x-3 hover:text-telecom-600 transition-colors"
          target={href.startsWith('http') ? '_blank' : undefined}
          rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
        >
          {content}
        </a>
      ) : (
        content
      )}
    </div>
  );
};

export default ContactSection;
