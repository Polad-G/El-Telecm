
import React from 'react';
import { Shield, Truck, Clock, CheckCircle } from 'lucide-react';

// Haqqımızda bölməsi komponenti
// Bu komponent şirkət haqqında məlumat təqdim edir
const AboutSection = () => {
  return (
    <section id="about" className="section-container bg-telecom-50 rounded-3xl my-16">
      <h2 className="section-title relative inline-block mx-auto">
        <span className="relative z-10">Haqqımızda</span>
        <div className="absolute bottom-0 left-0 h-3 w-full bg-telecom-200 -z-10 transform -rotate-1"></div>
      </h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Sol tərəf - Şirkət haqqında mətn */}
        <div className="space-y-6 animate-fade-in">
          <h3 className="text-2xl font-bold text-telecom-800">El Telecom - keyfiyyətli telefonların ünvanı</h3>
          
          <p className="text-gray-600 leading-relaxed">
            El Telecom olaraq müştərilərimizə ən yaxşı qiymətə ən keyfiyyətli məhsulları təqdim edirik. 
            Biz istifadə edilmiş telefonları yoxlayır, təmir edir və 1 il rəsmi zəmanətlə təqdim edirik.
          </p>
          
          <p className="text-gray-600 leading-relaxed">
            Bizim məqsədimiz hər kəsin büdcəsinə uyğun, lakin keyfiyyətdən güzəştə getmədən 
            premium telefonlara sahib olmağına imkan yaratmaqdır. Bütün məhsullarımız ciddi yoxlamadan keçir 
            və tam funksional vəziyyətdə təhvil verilir.
          </p>
          
          <div className="flex space-x-4 mt-8">
            <a href="#products" className="btn-primary">
              Məhsullarımıza baxın
            </a>
            <a href="#contact" className="btn-secondary">
              Bizimlə əlaqə
            </a>
          </div>
        </div>
        
        {/* Sağ tərəf - Üstünlüklərimiz */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Üstünlük kartları */}
          <FeatureCard 
            icon={<Shield className="h-8 w-8 text-telecom-500" />}
            title="1 il zəmanət"
            description="Bütün məhsullarımız 1 il rəsmi zəmanətlə təqdim olunur."
          />
          
          <FeatureCard 
            icon={<Truck className="h-8 w-8 text-telecom-500" />}
            title="Ölkə daxili çatdırılma"
            description="Bakı daxili pulsuz, regionlara sürətli çatdırılma xidməti."
          />
          
          <FeatureCard 
            icon={<CheckCircle className="h-8 w-8 text-telecom-500" />}
            title="Keyfiyyət yoxlaması"
            description="Bütün cihazlar peşəkar texniklər tərəfindən yoxlanılır."
          />
          
          <FeatureCard 
            icon={<Clock className="h-8 w-8 text-telecom-500" />}
            title="7/24 Dəstək"
            description="Həftənin hər günü müştəri dəstəyi xidmətinizdədir."
          />
        </div>
      </div>
    </section>
  );
};

// Üstünlük kartı komponenti
const FeatureCard = ({ 
  icon, 
  title, 
  description 
}: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
}) => {
  return (
    <div className="glass p-6 rounded-xl transform transition-transform hover:scale-105 hover:shadow-lg">
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-telecom-800 mb-2">{title}</h3>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
};

export default AboutSection;
