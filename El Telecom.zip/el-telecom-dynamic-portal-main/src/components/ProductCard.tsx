
import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Package, Tag } from 'lucide-react';
import { Product } from '../lib/productData';

interface ProductCardProps {
  product: Product;
}

// Məhsul kartı komponenti
// Bu komponent hər bir məhsul üçün kart yaradır
const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <Link 
      to={`/product/${product.id}`}
      className="card-3d bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300"
    >
      <div className="relative overflow-hidden group">
        {/* Məhsul şəkli */}
        <div className="h-48 overflow-hidden">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        
        {/* Qiymət etiketləri */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          {product.oldPrice && (
            <span className="bg-red-100 text-red-800 text-xs font-semibold py-1 px-2 rounded-lg line-through">
              {product.oldPrice} ₼
            </span>
          )}
          <span className="bg-telecom-500 text-white text-sm font-bold py-1 px-3 rounded-lg shadow-sm">
            {product.price} ₼
          </span>
        </div>
        
        {/* Zəmanət işarəsi */}
        <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm rounded-lg py-1 px-2 text-xs font-medium flex items-center text-telecom-800">
          <Shield className="h-3 w-3 mr-1 text-telecom-500" />
          1 il zəmanət
        </div>
      </div>
      
      {/* Məhsul məlumatları */}
      <div className="p-4">
        <h3 className="text-lg font-bold text-gray-900 mb-1">{product.name}</h3>
        
        <div className="flex flex-wrap gap-2 mt-2 mb-3">
          <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
            {product.memory}
          </span>
          <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800">
            {product.color}
          </span>
          <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-md bg-green-100 text-green-800">
            {product.condition}
          </span>
        </div>
        
        <div className="flex justify-between items-center mt-3">
          <span className="text-sm text-gray-500 flex items-center">
            <Package className="h-3 w-3 mr-1" />
            Stokda var
          </span>
          <span className="text-telecom-600 text-sm font-medium flex items-center hover:text-telecom-700">
            Ətraflı
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
            </svg>
          </span>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
