
// Bu fayl bütün məhsul məlumatlarını saxlayır
// Burada məhsul məlumatlarını əlavə edə və ya dəyişdirə bilərsiniz

export interface Product {
  id: number;
  name: string;
  price: number;
  oldPrice?: number;
  image: string;
  description: string;
  condition: string;
  warranty: string;
  memory: string;
  color: string;
  inStock: boolean;
}

// Məhsulların siyahısı - burada yeni məhsullar əlavə edə bilərsiniz
export const products: Product[] = [
  {
    id: 1,
    name: "iPhone 13 Pro",
    price: 1699,
    oldPrice: 1999,
    image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?q=80&w=1000&auto=format&fit=crop",
    description: "Əla vəziyyətdə, cızıqsız iPhone 13 Pro. Tam funksional, orijinal aksesuarlarla birlikdə.",
    condition: "Əla vəziyyətdə",
    warranty: "1 il rəsmi zəmanət",
    memory: "256GB",
    color: "Sierra Blue",
    inStock: true
  },
  {
    id: 2,
    name: "Samsung Galaxy S22",
    price: 1299,
    oldPrice: 1599,
    image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=1000&auto=format&fit=crop",
    description: "Yaxşı vəziyyətdə olan Samsung Galaxy S22. Arxa tərəfində kiçik cızıqlar var, ekran mükəmməldir.",
    condition: "Yaxşı vəziyyətdə",
    warranty: "1 il rəsmi zəmanət",
    memory: "128GB",
    color: "Phantom Black",
    inStock: true
  },
  {
    id: 3,
    name: "Google Pixel 6",
    price: 999,
    oldPrice: 1199,
    image: "https://images.unsplash.com/photo-1635870723802-e88d09e3eb19?q=80&w=1000&auto=format&fit=crop",
    description: "Əla vəziyyətdə olan Google Pixel 6. Heç bir cızıq və ya qüsur yoxdur.",
    condition: "Yeni kimidir",
    warranty: "1 il rəsmi zəmanət",
    memory: "128GB",
    color: "Stormy Black",
    inStock: true
  },
  {
    id: 4,
    name: "Xiaomi Mi 11",
    price: 799,
    oldPrice: 999,
    image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1000&auto=format&fit=crop",
    description: "Yaxşı vəziyyətdə olan Xiaomi Mi 11. Tam funksional, orijinal qutusu ilə.",
    condition: "Yaxşı vəziyyətdə",
    warranty: "1 il rəsmi zəmanət",
    memory: "256GB",
    color: "Midnight Gray",
    inStock: true
  }
];

// Məhsul ID-sinə görə məhsulu tapmaq üçün funksiya
export const getProductById = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
};
